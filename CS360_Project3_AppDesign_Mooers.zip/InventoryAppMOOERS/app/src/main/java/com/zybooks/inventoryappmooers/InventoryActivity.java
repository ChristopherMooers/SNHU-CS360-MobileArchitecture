package com.zybooks.inventoryappmooers;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/**
 * InventoryActivity displays inventory items in a grid-style layout
 * and supports CRUD operations using SQLite.
 */
public class InventoryActivity extends AppCompatActivity {

    private DBHelper dbHelper;
    private LinearLayout itemsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DBHelper(this);

        Button btnAddItem = findViewById(R.id.btnAddItem);
        Button btnSmsSettings = findViewById(R.id.btnSmsSettings);

        // This must exist in activity_inventory.xml (ScrollView -> LinearLayout)
        itemsContainer = findViewById(R.id.itemsContainer);

        btnAddItem.setOnClickListener(v -> showAddItemDialog());

        // Navigate to SMS screen
        btnSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsActivity.class);
            startActivity(intent);
        });

        refreshInventoryGrid();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshInventoryGrid();
    }

    /** Reads from SQLite and rebuilds the inventory display area. */
    private void refreshInventoryGrid() {
        itemsContainer.removeAllViews();

        Cursor cursor = dbHelper.getAllInventoryItems();

        if (cursor == null || cursor.getCount() == 0) {
            TextView empty = new TextView(this);
            empty.setText("(No inventory items yet)");
            empty.setGravity(Gravity.CENTER_HORIZONTAL);
            empty.setPadding(0, 40, 0, 0);
            itemsContainer.addView(empty);

            if (cursor != null) cursor.close();
            return;
        }

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DBHelper.COL_ITEM_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.COL_ITEM_NAME));
            int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.COL_ITEM_QTY));

            itemsContainer.addView(buildRow(id, name, qty));
        }

        cursor.close();
    }

    /** Builds one row that looks like: Item | Qty | Delete */
    private LinearLayout buildRow(long id, String name, int qty) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(8, 16, 8, 16);
        row.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        // Item name
        TextView tvName = new TextView(this);
        tvName.setText(name);
        tvName.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f
        ));

        // Quantity (tap to update)
        TextView tvQty = new TextView(this);
        tvQty.setText(String.valueOf(qty));
        tvQty.setGravity(Gravity.CENTER);
        tvQty.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        ));
        tvQty.setOnClickListener(v -> showUpdateItemDialog(id, name, qty));

        // Delete button
        Button btnDelete = new Button(this);
        btnDelete.setText("Delete");
        btnDelete.setAllCaps(false);
        btnDelete.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
        ));
        btnDelete.setOnClickListener(v -> {
            dbHelper.deleteInventoryItem(id);
            refreshInventoryGrid();
        });

        row.addView(tvName);
        row.addView(tvQty);
        row.addView(btnDelete);

        return row;
    }

    /** Dialog to add a new inventory item. */
    private void showAddItemDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 0);

        EditText etName = new EditText(this);
        etName.setHint("Item name");

        EditText etQty = new EditText(this);
        etQty.setHint("Quantity");
        etQty.setInputType(InputType.TYPE_CLASS_NUMBER);

        layout.addView(etName);
        layout.addView(etQty);

        new AlertDialog.Builder(this)
                .setTitle("Add Inventory Item")
                .setView(layout)
                .setPositiveButton("Add", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String qtyStr = etQty.getText().toString().trim();

                    if (name.isEmpty() || qtyStr.isEmpty()) {
                        Toast.makeText(this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qty = Integer.parseInt(qtyStr);
                    dbHelper.addInventoryItem(name, qty);
                    refreshInventoryGrid();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Dialog to update an existing item (name and/or qty). */
    private void showUpdateItemDialog(long id, String currentName, int currentQty) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 24, 48, 0);

        EditText etName = new EditText(this);
        etName.setHint("Item name");
        etName.setText(currentName);

        EditText etQty = new EditText(this);
        etQty.setHint("Quantity");
        etQty.setInputType(InputType.TYPE_CLASS_NUMBER);
        etQty.setText(String.valueOf(currentQty));

        layout.addView(etName);
        layout.addView(etQty);

        new AlertDialog.Builder(this)
                .setTitle("Update Item")
                .setView(layout)
                .setPositiveButton("Save", (dialog, which) -> {
                    String name = etName.getText().toString().trim();
                    String qtyStr = etQty.getText().toString().trim();

                    if (name.isEmpty() || qtyStr.isEmpty()) {
                        Toast.makeText(this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int qty = Integer.parseInt(qtyStr);
                    dbHelper.updateInventoryItem(id, name, qty);
                    refreshInventoryGrid();

                    if (qty == 0) {
                        SmsActivity.sendInventoryAlert(this, name);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

