package com.zybooks.inventoryappmooers;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.telephony.SmsManager;


import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private TextView tvSmsStatus;
    private Button btnRequestSms;

    private final ActivityResultLauncher<String> requestSmsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    tvSmsStatus.setText("Status: SMS permission granted");
                    Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
                } else {
                    tvSmsStatus.setText("Status: Permission denied");
                    Toast.makeText(this, "Permission denied. Notifications disabled.", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        tvSmsStatus = findViewById(R.id.tvSmsStatus);
        btnRequestSms = findViewById(R.id.btnRequestSms);

        // Initial permission check
        if (isSmsPermissionGranted()) {
            tvSmsStatus.setText("Status: SMS permission granted");
        } else {
            tvSmsStatus.setText("Status: Permission not granted");
        }

        btnRequestSms.setOnClickListener(v -> {
            if (isSmsPermissionGranted()) {
                Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            } else {
                requestSmsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });
    }

    private boolean isSmsPermissionGranted() {
        return ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED;
    }

    public static void sendInventoryAlert(AppCompatActivity activity, String itemName) {
        // Example recipient number for emulator testing:
        String phoneNumber = "5554"; // emulator-to-emulator example (can be changed)
        String message = "Inventory Alert: " + itemName + " is out of stock.";

        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(activity, "SMS permission denied. Alert not sent.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(activity, "SMS alert sent for: " + itemName, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(activity, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
