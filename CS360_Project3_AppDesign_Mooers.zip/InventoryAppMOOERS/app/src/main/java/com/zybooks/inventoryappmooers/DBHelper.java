package com.zybooks.inventoryappmooers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DBHelper manages the app's SQLite database.
 * This includes a Users table for login credentials.
 */
public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "inventory_app.db";
    private static final int DB_VERSION = 2;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "item_id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_ITEM_QTY = "quantity";


    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsers =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");";
        db.execSQL(createUsers);

        // Create inventory table
        String createInventory =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_ITEM_NAME + " TEXT NOT NULL, " +
                        COL_ITEM_QTY + " INTEGER NOT NULL" +
                        ");";
        db.execSQL(createInventory);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }


    /** Returns true if username already exists. */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=?",
                new String[]{username},
                null, null, null
        );

        boolean exists = cursor.moveToFirst();
        cursor.close();
        return exists;
    }

    /** Creates a new user. Returns true if inserted successfully. */
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    /** Returns true if username/password match a row in the database. */
    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null
        );

        boolean valid = cursor.moveToFirst();
        cursor.close();
        return valid;
    }

    // Add inventory item
    public long addInventoryItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, qty);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    // Get all inventory items
    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_INVENTORY,
                null,
                null,
                null,
                null,
                null,
                COL_ITEM_NAME + " ASC"
        );
    }

    // Update inventory item
    public int updateInventoryItem(long itemId, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, qty);

        return db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );
    }

    // Delete inventory item
    public int deleteInventoryItem(long itemId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );
    }
}

