package com.zybooks.inventoryappmooers;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity handles login and new account creation.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        dbHelper = new DBHelper(this);

        btnLogin.setOnClickListener((View v) -> handleLogin());
    }

    private void handleLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // Basic validation
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        // If user exists, validate password
        if (dbHelper.userExists(username)) {
            if (dbHelper.validateLogin(username, password)) {
                Toast.makeText(this, "Login successful.", Toast.LENGTH_SHORT).show();
                goToInventory();
            } else {
                Toast.makeText(this, "Incorrect password.", Toast.LENGTH_SHORT).show();
            }
        } else {
            // User does not exist -> prompt to create account
            showCreateAccountDialog(username, password);
        }
    }

    private void showCreateAccountDialog(String username, String password) {
        new AlertDialog.Builder(this)
                .setTitle("Create Account?")
                .setMessage("No account found for \"" + username + "\". Create a new account?")
                .setPositiveButton("Create", (dialog, which) -> {
                    boolean created = dbHelper.createUser(username, password);
                    if (created) {
                        Toast.makeText(this, "Account created. Logged in!", Toast.LENGTH_SHORT).show();
                        goToInventory();
                    } else {
                        Toast.makeText(this, "Could not create account (username may be taken).", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void goToInventory() {
        Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
        startActivity(intent);

    }
}

